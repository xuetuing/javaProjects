package com.itstyle.seckill.service;

import com.itstyle.seckill.common.entity.Result;

/**
 * 生成商品静态页
 * 创建者  小柒2012
 */
public interface ICreateHtmlService {
	Result createAllHtml();
}
